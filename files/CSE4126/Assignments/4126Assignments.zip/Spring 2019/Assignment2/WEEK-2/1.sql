clear screen;
drop table money;

create table money(id number, name varchar2(20), taka number);


insert into money values(1,'A',100);
insert into money values(2,'B',110);
insert into money values(3,'C',120);
--insert into money values(4,'D',130);
--insert into money values(5,'E',140);
--insert into money values(6,'F',150);

--commit;


clear screen;

select * from money;


