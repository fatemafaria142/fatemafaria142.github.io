-- Name: Nowshin Nawar Arony
-- ID: 14-02-04-067
-- Group: B1

set serveroutput on
declare 
        loopCount number :=1;

	tempID STUDENT.snum%TYPE;
        tempName STUDENT.sname%TYPE;
	tempMajor STUDENT.major%TYPE;
	tempLevel STUDENT.slevel%TYPE;
	tempAge STUDENT.age%TYPE;
        
	cursor GetID is
	select * from Student;

begin
	open GetID;
	loop
		fetch GetID into tempID,tempName, tempMajor,tempLevel,tempAge;
		exit when GetID%notfound;
		end loop;

	close GetID;

	DBMS_OUTPUT.PUT_LINE('ID of Last Student = '||TO_CHAR(tempID));
	loop
		if loopCount > 10
		then
			exit;
		end if;
                
		tempID := tempID + 1;
                insert into Student values(tempID,tempName, tempMajor,tempLevel,tempAge);
		loopCount:= loopCount + 1;
	
	end loop;
	
end;
/
