SET SERVEROUTPUT ON

DECLARE
	A NUMBER := 0;
	B money.id%TYPE;
	C money.name%TYPE;
	D money.taka%TYPE;
	E NUMBER := &x;
BEGIN
	IF E = 1 THEN 
		SELECT COUNT(id) into A FROM money;
		FOR R IN 1..A LOOP
			SELECT id, name, taka into B,C,D FROM money where id=R;
			INSERT INTO newmoney values(B, C, D);
			Delete from money where id=R;
		END LOOP;
	ELSE
		SELECT COUNT(id) into A FROM newmoney;
		FOR R IN 1..A LOOP
			SELECT id, name, taka into B,C,D FROM newmoney where id=R;
			INSERT INTO money values(B, C, D);
			Delete from newmoney where id=R;
		END LOOP;
	END IF;
END;
/